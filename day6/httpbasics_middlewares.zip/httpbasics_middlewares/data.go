package main

type Hotel struct {
	Name     string
	Id       int
	Location string
}
