package main

type StepCounter struct {
	count int
	step  int
}

func NewStepCounter(step int) StepCounter {
	return StepCounter{
		count: 0,
		step:  step,
	}
}

func (c *StepCounter) Incr() {
	c.count += c.step
}

func (c *StepCounter) Decr() {
	c.count -= c.step
}

func (c *StepCounter) GetValue() int {
	return c.count
}
