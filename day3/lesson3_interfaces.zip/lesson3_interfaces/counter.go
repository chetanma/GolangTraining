package main

import "fmt"

type Counter interface {
	Incr()
	Decr()
	GetValue() int
}

func StandardCounterOperations(c Counter) {
	c.Incr()
	c.Incr()
	c.Incr()
	c.Decr()
}

func PrintCounterState(c Counter) {
	fmt.Println(c.GetValue())
}
