package main

type Customer struct{}

type CustomerRepo interface {
	GetCustomer(id int) Customer
	GetCustomers(id ...int) []Customer
}

//in another file
type CustomerRepositoryJsonFile struct {
	file string
}

//Write initializer for above

//in some other dummy file like test
//in memory
type CustomerRepoDummy struct {
}
