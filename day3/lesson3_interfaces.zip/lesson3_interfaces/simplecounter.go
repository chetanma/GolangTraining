package main

type SimpleCounter struct {
	count int
}

func (c *SimpleCounter) Incr() {
	c.count += 1
}

func (c *SimpleCounter) Decr() {
	c.count -= 1
}

func (c *SimpleCounter) GetValue() int {
	return c.count
}
