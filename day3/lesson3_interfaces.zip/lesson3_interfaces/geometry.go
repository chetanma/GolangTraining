package main

import "fmt"

type Geometry interface {
	Area() float32
}

type Rectange struct {
	W float32
	H float32
}

func (r Rectange) Area() float32 {
	return r.H * r.W
}

func CalculateArea(g Geometry) {
	fmt.Println(g.Area())
}
