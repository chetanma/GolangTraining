package main

import "fmt"

func main() {
	SimpleCounterDemo()
	StepCounterDemo()

	GemetryDemo()

	//Read the repo file just for understanding.

}

func RepoDemo() {
	//replace this with proper initializer func
	//repoJsonfile := CustomerRepositoryJsonFile{}
	//RepoOperations(&repoJsonfile)

	//replace this with proper initializer func
	//inMemDummy := CustomerRepoDummy{}
	//RepoOperations(&inMemDummy)
}

func RepoOperations(repo CustomerRepo) {
	cust := repo.GetCustomer(1001)
	fmt.Println(cust)

	cust = repo.GetCustomer(1005)
	fmt.Println(cust)

	custs := repo.GetCustomers(1001, 1002, 1005, 1010)
	fmt.Println(custs)
}

func SimpleCounterDemo() {
	sc := SimpleCounter{}
	StandardCounterOperations(&sc)
	PrintCounterState(&sc)
}

func StepCounterDemo() {
	stc := NewStepCounter(5)
	StandardCounterOperations(&stc)
	PrintCounterState(&stc)
}

func GemetryDemo() {
	CalculateArea(Rectange{H: 10.0, W: 5.0})
}
