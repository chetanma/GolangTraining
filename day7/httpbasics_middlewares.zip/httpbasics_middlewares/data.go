package main

type Hotel struct {
	Name     string
	Id       int
	Location string
}

type Product struct {
	Name  string
	Id    int
	Price float32
}
