package main

func main() {

	//InvokeWorkersSync()
	VariablesAndPointers()

}
